.. :changelog:

History
-------

"1.0.0" (2023-04-13)
---------------------

* First release on PyPI.